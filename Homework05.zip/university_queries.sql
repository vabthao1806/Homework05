

USE university_db;

/*
 * Query 1: Basic SELECT
 * Description: Retrieves all columns and records from the students table to view complete student profiles.
 * Expected Output: A list of all students with their IDs, codes, names, email, gender, birth date, GPA, and department ID.
 */
SELECT * 
FROM students;

/*
 * Query 2: WHERE with Comparison
 * Description: Filters student records to find high-performing students whose GPA is strictly greater than 3.0.
 * Expected Output: A list of students who have a GPA above 3.0.
 */
SELECT * 
FROM students 
WHERE gpa > 3.0;

/*
 * Query 3: WHERE with AND/OR
 * Description: Combines multiple conditions to find courses that belong to department 1 and have 3 or more credits.
 * Expected Output: Courses matching both criteria (department 1 and credits >= 3).
 */
SELECT * 
FROM courses 
WHERE department_id = 1 AND credits >= 3;

/*
 * Query 4: ORDER BY
 * Description: Sorts all student records in descending order based on their GPA to quickly identify top ranks.
 * Expected Output: All students ordered from highest GPA to lowest GPA.
 */
SELECT * 
FROM students 
ORDER BY gpa DESC;

/*
 * Query 5: LIMIT
 * Description: Returns only the top 3 students with the highest GPA by combining sorting and row limitation.
 * Expected Output: Exactly 3 student records with the highest GPAs.
 */
SELECT * 
FROM students 
ORDER BY gpa DESC 
LIMIT 3;


/*
 * Query 6: LIKE
 * Description: Searches for courses whose titles contain the keyword "Introduction" using the LIKE operator and wildcards.
 * Expected Output: Courses matching the pattern '%Introduction%'.
 */
SELECT * 
FROM courses 
WHERE title LIKE '%Introduction%';


/*
 * Query 7: Aggregate — COUNT / SUM
 * Description: Computes the total sum of all course credits across the university using the SUM aggregate function.
 * Expected Output: A single row displaying the total credits of all available courses with a column alias.
 */
SELECT SUM(credits) AS total_course_credits 
FROM courses;

/*
 * Query 8: Aggregate with GROUP BY + HAVING
 * Description: Groups students by department and filters departments that have more than 1 student enrolled.
 * Expected Output: Department IDs and their respective student counts where count > 1.
 */
SELECT department_id, COUNT(*) AS student_count 
FROM students 
GROUP BY department_id 
HAVING COUNT(*) > 1;


/*
 * Query 9: JOIN — Two Tables
 * Description: Joins the courses and instructors tables using a foreign key relationship to show course details alongside instructor names.
 * Expected Output: Course codes, titles, and instructor full names with custom aliases.
 */
SELECT 
    c.course_code, 
    c.title AS course_title, 
    i.full_name AS instructor_name 
FROM courses c 
JOIN instructors i ON c.instructor_id = i.id 
ORDER BY c.course_code;


/*
 * Query 10: JOIN — Three or More Tables
 * Description: Performs a multi-table join across enrollments, students, courses, and semesters to present comprehensive registration details.
 * Expected Output: Enrollment ID, student name, course title, semester name, and student grade.
 */
SELECT 
    e.id AS enrollment_id, 
    s.full_name AS student_name, 
    c.title AS course_title, 
    sem.name AS semester_name, 
    e.grade 
FROM enrollments e 
JOIN students s ON e.student_id = s.id 
JOIN courses c ON e.course_id = c.id 
JOIN semesters sem ON e.semester_id = sem.id 
ORDER BY e.id;
